/**
 * @author Ben Forgy at touro
 * 11/13/13
 */
package mousecatcher;

public class MouseCatcher {

    public static void main(String[] args) {
       
        MouseCatcherGame mouseCatcherGame = new MouseCatcherGame(); 
        mouseCatcherGame.start();
        System.exit(0);
    }
}
