package mousecatcher;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Ben Forgy at touro
 */
public class MouseCatcherTest {

    @Test
    public void pointList()
    {
        PointList list = new PointList(8);
    }
}